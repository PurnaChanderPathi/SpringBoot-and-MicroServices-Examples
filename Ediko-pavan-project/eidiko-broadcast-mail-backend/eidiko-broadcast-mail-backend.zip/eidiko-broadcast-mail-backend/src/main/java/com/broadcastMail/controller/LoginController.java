package com.broadcastMail.controller;

import com.broadcastMail.dto.LoginDto;
import com.broadcastMail.serviceImpl.JwtServiceImpl;
import com.broadcastMail.serviceImpl.UserSecurityDetailsImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("api/v1/mail")
public class LoginController {

    @Autowired
    private UserSecurityDetailsImpl userService;
    @Autowired
    private JwtServiceImpl service;
    @Autowired
    private AuthenticationManager authenticate;

    @PostMapping("/login")
    public ResponseEntity<Map<String, Object>> login(@RequestBody LoginDto loginDto) throws Exception {
        this.authenticate(loginDto.getMailId(), loginDto.getPassword());
        UserDetails userDetails = this.userService.loadUserByUsername(loginDto.getMailId());
        String token = this.service.generateToken(userDetails.getUsername());
        Map<String, Object> map = new HashMap<>();
        map.put("token", token);
        map.put("token expiration time", this.service.getExpirationDateFromToken(token).toString());
        map.put("token expiration time in milli seconds", this.service.getExpirationDateFromToken(token).getTime());
        map.put("message", "success");
        map.put("status", "success");
        map.put("username", userDetails.getUsername());
        map.put("user-role", userDetails.getAuthorities().stream().map(auth -> auth.getAuthority()));

        return ResponseEntity.ok().body(map);

    }
    private void authenticate(String username,String password) throws Exception {
        UsernamePasswordAuthenticationToken authenticationToken=new UsernamePasswordAuthenticationToken(username,password);
        try {
            this.authenticate.authenticate(authenticationToken);
        }
        catch (DisabledException e)
        {
            throw new DisabledException("user is disabled");
        }
        catch (BadCredentialsException e)
        {
            throw new BadCredentialsException("bad credentials");
        }
    }
}
