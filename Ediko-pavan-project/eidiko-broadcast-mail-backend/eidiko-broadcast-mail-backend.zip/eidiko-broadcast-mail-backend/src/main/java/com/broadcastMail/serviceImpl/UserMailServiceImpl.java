package com.broadcastMail.serviceImpl;

import com.broadcastMail.config.EmailConfig;
import com.broadcastMail.dto.SigninDto;
import com.broadcastMail.dto.UploadExcelDto;
import com.broadcastMail.entites.MailCredentials;
import com.broadcastMail.entites.User;
import com.broadcastMail.exception.InvalidFileExtensionException;
import com.broadcastMail.exception.UserAlreadyExistsException;
import com.broadcastMail.repository.MailCredentialsRepository;
import com.broadcastMail.repository.UserRepository;
import com.broadcastMail.service.UserMailService;
import jakarta.mail.internet.MimeMessage;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpStatus;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Service
public class UserMailServiceImpl implements UserMailService {
    @Autowired
    private UserRepository repository;
    @Autowired
    private PasswordEncoder encoder;


    @Autowired
    private MailCredentialsRepository mailCredentialsRepository;
    @Autowired
    private EmailConfig emailConfig;

    @Value("${files.storage}")
    public String folderLocation;


    private final ExecutorService executorService = Executors.newFixedThreadPool(1);

    Map<String, Object> map = new HashMap<>();


    @Override
    public Map<String, Object> createUser(SigninDto signinDto) {
        User user1 = this.repository.findByMailId(signinDto.getMailId());
        if (user1 != null) {
            throw new UserAlreadyExistsException("customer is alresady exists with this mail Id");
        }

        User user2 = new User();
        user2.setMailId(signinDto.getMailId());
        user2.setPassword(encoder.encode(signinDto.getPassword()));
        user2.setRole("user");
        this.repository.save(user2);
        map.put("status", HttpStatus.CREATED.value());
        map.put("mesage", "created successfully");
        map.put("result", user2);
        return map;
    }

//    @Override
//    public Map<String, Object> uploadExcel(UploadExcelDto excelDto) throws IOException {
//        String fileName = excelDto.getFile().getOriginalFilename();
//        String fileExtension = StringUtils.getFilenameExtension(fileName);
//        ArrayList<String> allowedExtensions = new ArrayList<>(Arrays.asList("xls", "xlsx", "csv"));
//        if (!allowedExtensions.contains(fileExtension)) {
//            throw new InvalidFileExtensionException("Please provide an Excel file.");
//        }
//
//        List<String> emailList = new ArrayList<>();
//        XSSFWorkbook workbook = new XSSFWorkbook(excelDto.getFile().getInputStream());
//        XSSFSheet sheet = workbook.getSheetAt(0);
//        for (int i = 1; i < sheet.getPhysicalNumberOfRows(); i++) {
//            XSSFRow row = sheet.getRow(i);
//            if (row != null) {
//                String nameCell = String.valueOf(row.getCell(1));
//                String emailCell = String.valueOf(row.getCell(2));
//                String appraisalTypeCell = String.valueOf(row.getCell(3));
//                String appraisalScoreCell = String.valueOf(row.getCell(4));
//                Date dueDateCell = row.getCell(5).getDateCellValue();
//                Instant instant = dueDateCell.toInstant();
//                String formattedDueDate = DateTimeFormatter
//                        .ofPattern("dd-MM-yyyy")
//                        .withZone(ZoneId.systemDefault())
//                        .format(instant);
//                if (nameCell != null && emailCell != null) {
//                    executorService.submit(() -> {
//                        try {
//                            if (excelDto.getAttachments() != null) {
//                                sendingMailsOneByOne(excelDto.getUsername(), excelDto.getPassword(), nameCell, emailCell, appraisalTypeCell, appraisalScoreCell, formattedDueDate, excelDto.getSubject(), excelDto.getAttachments());
//                            } else {
//                                sendingMailsOneByOneWithoutAttachments(excelDto.getUsername(), excelDto.getPassword(), nameCell, emailCell, appraisalTypeCell, appraisalScoreCell, formattedDueDate, excelDto.getSubject());
//                            }
//                        } catch (Exception ex) {
//                            ex.printStackTrace();
//
//                        }
//                    });
//                }
//            }
//        }
//        map.put("status", HttpStatus.CREATED.value());
//        map.put("message", "Mail sent successfully");
//
//        return map;
//    }

    @Override
    public Map<String, Object> saveMailCredentials(MailCredentials credentials) {
        MailCredentials mailCredentials = this.mailCredentialsRepository.findByMailId(credentials.getMailId());
        if (mailCredentials != null) {
            throw new UserAlreadyExistsException("this mail credentials already exists");
        }
        MailCredentials mailCredentials1 = new MailCredentials();
        mailCredentials1.setMailId(credentials.getMailId());
        mailCredentials1.setPassword(credentials.getPassword());
        this.mailCredentialsRepository.save(mailCredentials1);
        map.put("status", HttpStatus.CREATED.value());
        map.put("mesage", "created successfully");
        map.put("result", mailCredentials1);
        return map;
    }

    @Override
    public Map<String, Object> getAllMailCredentials() {
        List<MailCredentials> list = this.mailCredentialsRepository.findAll();
        map.put("status", HttpStatus.OK.value());
        map.put("message", "fetched successfully");
        map.put("result", list);
        return map;
    }


    @Async
    private void sendingMailsOneByOne(String username, String password, String name, String emails, String appraisalType, String appraisalScore, String dueDate, String subject, List<MultipartFile> attachments) throws Exception {
        JavaMailSender javaMailSender = emailConfig.getJavaMailSender(username, password);
        MimeMessage mail = javaMailSender.createMimeMessage();
        MimeMessageHelper mimeMessageHelper = new MimeMessageHelper(mail, true);

        mimeMessageHelper.addTo(emails);
        String template = readingMailTemplateFromText("appraisal-mail.txt");
        String processedTemplate = template.replace("@empName", name).replace("@typeOfAppraisal", appraisalType).replace("@appraisalScore", appraisalScore).replace("@dueDate", dueDate.toString());
        mimeMessageHelper.setFrom(username);
        mimeMessageHelper.setSubject("[Broadcast] " + subject);

        if (attachments != null && !attachments.isEmpty()) {
            for (MultipartFile attachment : attachments) {
                if (attachment != null && !attachment.isEmpty()) {
                    mimeMessageHelper.addAttachment(Objects.requireNonNull(attachment.getOriginalFilename()), new ByteArrayResource(attachment.getBytes()));
                }
            }
        }

        mimeMessageHelper.setText(processedTemplate, true);
        javaMailSender.send(mail);
    }

    private void sendingMailsOneByOneWithoutAttachments(String username, String password, String name, String emails, String appraisalType, String appraisalScore, String dueDate, String subject) throws Exception {
        JavaMailSender javaMailSender = emailConfig.getJavaMailSender(username, password);
        MimeMessage mail = javaMailSender.createMimeMessage();
        MimeMessageHelper mimeMessageHelper = new MimeMessageHelper(mail, true);

        mimeMessageHelper.addTo(emails);
        String template = readingMailTemplateFromText("appraisal-mail.txt");
        String processedTemplate = template.replace("@empName", name).replace("@typeOfAppraisal", appraisalType).replace("@appraisalScore", appraisalScore).replace("@dueDate", dueDate.toString());
        mimeMessageHelper.setFrom(username);
        mimeMessageHelper.setSubject("[Broadcast] " + subject);
        mimeMessageHelper.setText(processedTemplate, true);

        javaMailSender.send(mail);
    }

    private String readingMailTemplateFromText(String fileName) throws Exception {
        try {
            String fullFileName = folderLocation + "/" + fileName;
            File file = new File(fullFileName);
            return new String(Files.readAllBytes(file.toPath()));
        } catch (IOException e) {
            throw new Exception("Mail not sent");
        }
    }



}
