package com.broadcastMail.service;

import com.broadcastMail.dto.UploadExcelDto;
import com.broadcastMail.exception.FolderDoesNotExistsException;

import java.io.IOException;
import java.util.Map;

public interface UserMassMailService {
    Map<String, Object> massMails(UploadExcelDto excelDto) throws IOException;

    Map<String, Object> deleteFolder(String folderName) throws IOException, FolderDoesNotExistsException;

    Map<String, Object> getAllFolders();
}
