package com.broadcastMail.exception;

public class InvalidFileExtensionException extends RuntimeException{

    public InvalidFileExtensionException(String message)
    {
        super(message);
    }
}
