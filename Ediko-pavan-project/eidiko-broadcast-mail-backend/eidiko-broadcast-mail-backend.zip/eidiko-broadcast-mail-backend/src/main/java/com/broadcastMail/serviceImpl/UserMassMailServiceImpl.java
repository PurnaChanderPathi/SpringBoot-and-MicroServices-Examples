package com.broadcastMail.serviceImpl;

import com.broadcastMail.config.EmailConfig;
import com.broadcastMail.dto.UploadExcelDto;
import com.broadcastMail.entites.FolderEntity;
import com.broadcastMail.exception.FolderDoesNotExistsException;
import com.broadcastMail.exception.InvalidFileExtensionException;
import com.broadcastMail.repository.FolderRepository;
import com.broadcastMail.service.UserMassMailService;
import jakarta.mail.internet.MimeMessage;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.tomcat.util.http.fileupload.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpStatus;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

@Service
public class UserMassMailServiceImpl implements UserMassMailService {

    @Autowired
    private EmailConfig emailConfig;
    @Autowired
    private FolderRepository folderRepository;

    @Value("${files.storage}")
    public String folderLocation;

    private final ExecutorService executorService = Executors.newFixedThreadPool(1);

    Map<String, Object> resultMap = new HashMap<>();
    @Override
    public Map<String, Object> massMails(UploadExcelDto excelDto) throws IOException {
        String extractedFileName = unzipFile(excelDto.getZipFile());
        FolderEntity entity=new FolderEntity();
        entity.setFolderName(extractedFileName);
        folderRepository.save(entity);
        String fileName = excelDto.getFile().getOriginalFilename();
        String fileExtension = StringUtils.getFilenameExtension(fileName);
        ArrayList<String> allowedExtensions = new ArrayList<>(Arrays.asList("xls", "xlsx", "csv"));
        if (!allowedExtensions.contains(fileExtension)) {
            throw new InvalidFileExtensionException("Please provide an Excel file.");
        }
        XSSFWorkbook workbook = new XSSFWorkbook(excelDto.getFile().getInputStream());
        XSSFSheet sheet = workbook.getSheetAt(0);
        for (int i = 1; i < sheet.getPhysicalNumberOfRows(); i++) {
            XSSFRow row = sheet.getRow(i);
            if (row != null) {
                List<String> entireRowCells = new ArrayList<>();
                List<String> filenameAndEmpidCells = new ArrayList<>();

                for (int j = 0; j < row.getLastCellNum(); j++) {
                    XSSFCell cell = row.getCell(j);
                    if (cell != null) {
                        String cellValue = String.valueOf(cell);
                        String columnName = getColumnName(sheet.getRow(0).getCell(j));
                        if (columnName.equalsIgnoreCase("emailId") || columnName.equalsIgnoreCase("filename")) {
                            filenameAndEmpidCells.add(cellValue);
                        }
                        entireRowCells.add(cellValue);
                    }
                }

                sendEmail(excelDto, filenameAndEmpidCells, entireRowCells,extractedFileName);

            }
        }

        resultMap.put("status", HttpStatus.CREATED.value());
        resultMap.put("message", "Mail sent successfully");
        return resultMap;
    }

    @Override
    public Map<String, Object> deleteFolder(String folderName) throws IOException {
        String fName=folderLocation+"/"+folderName;
        File folder = new File(fName);
        if (!folder.exists()) {
            throw new FolderDoesNotExistsException("File doesn't exists in your machine");
        }
        FileUtils.deleteDirectory(folder);
        resultMap.put("status", HttpStatus.OK.value());
        resultMap.put("message", "Folder Deleted successfully");
        this.folderRepository.deleteByFolderName(folderName);
        return resultMap;
    }

    @Override
    public Map<String, Object> getAllFolders() {
        List<FolderEntity>  list= this.folderRepository.findAll();
       resultMap.put("status",HttpStatus.OK.value());
       resultMap.put("message","fetched successfully");
       resultMap.put("result",list);
        return resultMap;
    }

    private String getColumnName(XSSFCell cell) {
        if (cell != null) {
            return cell.getStringCellValue().trim();
        }
        return "";
    }

    private void sendEmail(UploadExcelDto excelDto, List<String> emailAndFilenameList, List<String> cellValueList,String extractedFileName) throws IOException {
        executorService.submit(() -> {
            try {
                if (emailAndFilenameList != null &&!emailAndFilenameList.isEmpty() ) {
                    JavaMailSender javaMailSender = emailConfig.getJavaMailSender(excelDto.getUsername(), excelDto.getPassword());
                    MimeMessage mail = javaMailSender.createMimeMessage();
                    MimeMessageHelper mimeMessageHelper = new MimeMessageHelper(mail, true);
                    File file = searchFileInLocalDirectory(extractedFileName,emailAndFilenameList.get(1));
                    String body = excelDto.getBody();
                    for (int i = 0; i < cellValueList.size(); i++) {
                        String placeholder = "{" + i + "}";
                        body = body.replace(placeholder, cellValueList.get(i));
                    }

                    String recipientEmail = emailAndFilenameList.get(0);
                    mimeMessageHelper.setTo(recipientEmail);
                    mimeMessageHelper.setText(body);
                    mimeMessageHelper.setFrom(excelDto.getUsername());
                    mimeMessageHelper.setSubject("[Broadcast] " + excelDto.getSubject());

                    if (file != null && file.exists()) {
                        FileSystemResource fileSystemResource = new FileSystemResource(file);
                        mimeMessageHelper.addAttachment(file.getName(), fileSystemResource);
                    }

                    javaMailSender.send(mail);
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });
    }



    private File searchFileInLocalDirectory(String folderName,String fileName) {
        String directoryPath = folderLocation+"/"+folderName;
        File directory = new File(directoryPath);
        if (directory.exists() && directory.isDirectory()) {
            File[] files = directory.listFiles((dir, name) -> name.equals(fileName));
            if (files != null && files.length > 0) {
                return files[0];
            }
        }
        return null;
    }

    private String unzipFile(MultipartFile zipFile) throws IOException {

        File folder = new File(folderLocation);
        folder.mkdir();
        byte[] buffer = new byte[1024];
        ZipInputStream zis = new ZipInputStream(zipFile.getInputStream());
        ZipEntry zipEntry = zis.getNextEntry();
        String folderName = null;
        while (zipEntry != null) {
            File newFile = new File(folder, zipEntry.getName());
            if (zipEntry.isDirectory()) {
                newFile.mkdirs();
                if (folderName == null) {
                    folderName = newFile.getName();
                }
            } else {
                FileOutputStream fos = new FileOutputStream(newFile);
                int len;
                while ((len = zis.read(buffer)) > 0) {
                    fos.write(buffer, 0, len);
                }
                fos.close();
            }
            zipEntry = zis.getNextEntry();
        }

        zis.closeEntry();
        zis.close();

        return folderName;
    }

}
