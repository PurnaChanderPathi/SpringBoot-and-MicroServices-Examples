package com.broadcastMail;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EidikoBroadcastMailBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(EidikoBroadcastMailBackendApplication.class, args);
	}

}
